App({
  onCreate() {
    console.log("app created")
  },
  onDestroy() {
    console.log("app destroyed")
  }
})
